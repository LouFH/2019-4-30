function showInfo(item, msg) {
	$("#" + item.id + "_msg").html(msg);
	$("#" + item.id + "_msg").removeClass("validate_ok").removeClass("validate_error").addClass("validate_info");
}

function showError(item, msg) {
	$("#" + item.id + "_msg").html(msg);
	$("#" + item.id + "_msg").removeClass("validate_error").removeClass("validate_info").addClass("validate_error");
}

function showOk(item, msg) {
	// 如果传了msg,则显示msg,不如不传,由显示对号
	if (!msg) 
		msg = "√";

	$("#" + item.id + "_msg").html(msg);
	$("#" + item.id + "_msg").removeClass("validate_info").removeClass(	"validate_error").addClass("validate_ok");
		
}
