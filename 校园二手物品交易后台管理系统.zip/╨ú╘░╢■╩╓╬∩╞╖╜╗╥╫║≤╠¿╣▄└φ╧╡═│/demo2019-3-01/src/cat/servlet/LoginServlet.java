package cat.servlet;

import cat.beans.AdminInfo;
import cat.commons.Enums;
import cat.dao.AdminDao;
import cat.utils.Des;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AdminDao adminDao = new AdminDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");

		String flag = request.getParameter("flag");

		if ("login".equals(flag)) {
			this.login(request, response);
		}
		else if("refresh".equals(flag)){
			this.refresh(request,response);
		}
		else if("logout".equals(flag)){
			this.logOut(request,response);
		}
	}
 
	//�˳�(ע��)
	private void logOut(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.getSession().invalidate();
		response.getWriter().print("1");
	}

	//̽�� session (��ֹ����ʱ) ,���ص�ǰʱ��
	private void refresh(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		HttpSession session=request.getSession();
		AdminInfo admin=(AdminInfo)session.getAttribute("admin");  //�ó����ַŻ�ȥ,����Ϊ�˸��� Session
		session.setAttribute("admin", admin);
		
		String date= new SimpleDateFormat("yyyy-MM-dd E hh:mm").format(new java.util.Date());
		response.getWriter().print(date);
		
	}

	private void login(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		String adminName = request.getParameter("adminName");
		String password = request.getParameter("password");

		AdminInfo admin = adminDao.getLoginAdmin(adminName, Des.encStr(password));

		if (admin != null) {
			if (admin.getState().equals(Enums.EmnuAdminState.����.getValue())) {
				response.getWriter().print("2"); // 2 ��ʾ�û��˺ű�����
			} else {
				request.getSession().setAttribute("admin", admin);
				response.getWriter().print("1"); // 1 ��ʾ��¼�ɹ�
			}
		} else {
			response.getWriter().print("0"); // 0 ��ʾ��¼ʧ��
		}

	}

}
