package cat.servlet;

import cat.beans.AdminInfo;
import cat.commons.Enums;
import cat.dao.AdminDao;
import cat.dao.PermDao;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import cat.utils.StrUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class PermServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminDao adminDao=new AdminDao();
	private PermDao permDao=new PermDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		String flag=request.getParameter("flag");
		
		if("listadmin".equals(flag)){
			this.listadmin(request, response);
		}
		
		else if("updatperm".equals(flag)){
			this.updatperm(request,response);
		}
	}

	//�����û�Ȩ��
	private void updatperm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		int adminId=Integer.parseInt(request.getParameter("id"));
		String [] idList=request.getParameterValues("menuIds");
		
		permDao.updatePerm(adminId,idList);
		
		request.setAttribute("msg", "�����ɹ�");
		request.getRequestDispatcher("/perm/perm_edit.jsp").forward(request, response);;	
	}

		//��ѯ�û��б�,ת��Ȩ��ά����ҳ
		private void listadmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
			int pageIndex=1;
			
			String pageIndexStr=request.getParameter("pageIndex");
			if(!StrUtil.isNullOrEmpty(pageIndexStr)){
				pageIndex=Integer.parseInt(pageIndexStr);
			}
			
			int rowCount=adminDao.getAdminCount();
			
			PageInfo page= PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
			List<AdminInfo> adminList=adminDao.getAdminList(page);
			
			request.setAttribute("adminList", adminList);
			request.setAttribute("pageInfo", page);

			request.getRequestDispatcher("/perm/listadmin.jsp").forward(request, response);

		}

}
