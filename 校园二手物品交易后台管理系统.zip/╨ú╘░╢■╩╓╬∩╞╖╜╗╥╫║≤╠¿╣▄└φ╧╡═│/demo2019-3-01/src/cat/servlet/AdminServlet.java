package cat.servlet;

import cat.beans.AdminInfo;
import cat.commons.Enums;
import cat.dao.AdminDao;
import cat.utils.Des;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import cat.utils.StrUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AdminDao adminDao=new AdminDao();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");	
		
		String flag = request.getParameter("flag");
		
		if ("checkName".equals(flag)) {
			this.checkName(request, response);
		}
		else if("addAdmin".equals(flag)){
			this.addAdmin(request,response);
		}

		else if("manage".equals(flag)){
			this.manage(request,response);
		}
		
		else if("delAdmins".equals(flag)){
			this.delAdmins(request,response);
		}
		
		else if("del".equals(flag)){
			this.del(request,response);
		}
		
		else if("lock".equals(flag)){
			this.lock(request,response);
		}
		
		else if("updatePassword".equals(flag)){
			this.updatePassword(request,response);
		}
		
		else if("searchforupdate".equals(flag)){
			this.searchForUpdate(request, response);
		}
		
		else if("updateadmin".equals(flag)){
			this.updateAdmin(request,response);
		}
	}

	//�����û���Ϣ
	private void updateAdmin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int adminId=Integer.parseInt(request.getParameter("id"));
		AdminInfo adminInfo=adminDao.getAdminById(adminId);
		
		adminInfo.setNote(request.getParameter("note"));
		if(adminDao.updateAdmin(adminInfo)==1){
			request.setAttribute("msg","����Ա��Ϣ���³ɹ�! ");
			request.setAttribute("adminInfo",adminInfo);   //��adminInfo ���� admin��ԭ���Ƿ�ֹ�� session �е�admin ����
			request.getRequestDispatcher("/admin/admin_edit.jsp").forward(request, response);
		}	
	}

	//��ѯ���û���Ϣ,ת���޸�ҳ��
	private void searchForUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int adminId=Integer.parseInt(request.getParameter("id"));
		AdminInfo admin=adminDao.getAdminById(adminId);
		request.setAttribute("adminInfo", admin);
		request.getRequestDispatcher("/admin/admin_edit.jsp").forward(request, response);	
	}

	//�����û�����
	private void updatePassword(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
			AdminInfo admin=(AdminInfo)request.getSession().getAttribute("admin");
			String oldPassword=request.getParameter("oldPassword");
			
			if(!Des.encStr(oldPassword).equals(admin.getPassword())){
				request.setAttribute("msg", "����ʧ��! ���������벻��ȷ!");
				request.getRequestDispatcher("/admin/password_edit.jsp").forward(request, response);
			}
			
			else{
				String newPassword=request.getParameter("password");		
				if(adminDao.updatePassword(admin.getId(), Des.encStr(newPassword))==1){
					request.setAttribute("msg", "������³ɹ�!");
					request.getRequestDispatcher("/admin/password_edit.jsp").forward(request, response);
				}
			}
		
	}

	//����������û�
	private void lock(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lockFlag=request.getParameter("lockFlag");
		int id=Integer.parseInt(request.getParameter("id"));
		
		if(adminDao.setLock(id,lockFlag)==1){
			request.setAttribute("msg", "�����ɹ�!");
			this.manage(request, response);
		}
	}

	//����idɾ�������û�
	private void del(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		
		//��֤,�������û�ɾ������,�ڿͻ���,Ҳ��������֤
		AdminInfo admin=(AdminInfo) request.getSession().getAttribute("admin");
		if(id==admin.getId()){
			request.setAttribute("msg", "����ʧ��! ������ɾ������!");
			this.manage(request, response);
		}

		else if(adminDao.delAdminById(id)==1){
			request.setAttribute("msg", "�û�ɾ���ɹ�!");
			this.manage(request, response);
		}
		
	}

	//ͬʱɾ������û�
	private void delAdmins(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String [] idList=request.getParameterValues("ck_id");  //������ѡ�е��˵�ID������
		adminDao.delAdminByIdList(idList);
		
		//ת����?
		request.setAttribute("msg", "ɾ���ɹ�");
		this.manage(request, response);
	}

	//��ѯ�û��б�,ת���û�ά��ҳ��
	private void manage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int pageIndex=1;
		
		String pageIndexStr=request.getParameter("pageIndex");
		if(!StrUtil.isNullOrEmpty(pageIndexStr)){
			pageIndex=Integer.parseInt(pageIndexStr);
		}
		
		int rowCount=adminDao.getAdminCount();
		
		PageInfo page= PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
		List<AdminInfo> adminList=adminDao.getAdminList(page);
		
		request.setAttribute("adminList", adminList);
		request.setAttribute("pageInfo", page);

		request.getRequestDispatcher("/admin/admin_manage.jsp").forward(request, response);

	}

	//���ӹ���Ա
	private void addAdmin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String adminName=request.getParameter("adminName");
		String password=request.getParameter("password");
		String note=request.getParameter("note");
		
	
		AdminInfo admin=new AdminInfo();
		admin.setAdminName(adminName);
		admin.setPassword(Des.encStr(password));  //��Ҫ���˼���
		admin.setNote(note);
		admin.setState(Enums.EmnuAdminState.����.getValue());   // ���� ��Ӧ��ֵ�� 1
		//editDate ��ô���� ,���ô���,��Ϊ���ݿ�����������ֶ���ʱ���,���Զ�����
		
		if(adminDao.addAdmin(admin)==1){
			request.setAttribute("msg", "����Ա���ӳɹ� !");
			request.getRequestDispatcher("/admin/admin_add.jsp").forward(request, response);
		}	
	}

	// ������֤�ù���Ա�˺��Ƿ��ظ�(�ڹ���Ա����ҳ��)
	// ���� 0 ��ʾ�˺��Ѿ���ʹ��,1 ��ʾ�˺ſ���
	private void checkName(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		String adminName=request.getParameter("adminName");
		AdminInfo admin=adminDao.getAdminByAcc(adminName);
		if(admin!=null){
			response.getWriter().print("0");
		}
		else{
			response.getWriter().print("1");
		}
	}

}
