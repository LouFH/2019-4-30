package cat.servlet;

import cat.beans.AdminInfo;
import cat.beans.RoleInfo;
import cat.commons.Enums;
import cat.dao.AdminDao;
import cat.dao.RoleDao;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import cat.utils.StrUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class RoleServlet extends HttpServlet {
	RoleDao roleDao=new RoleDao();
	private AdminDao adminDao=new AdminDao();
	
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String flag=request.getParameter("flag");
		if("addrole".equals(flag)){
			this.addRole(request,response);
		}
		
		else if("manage".equals(flag)){
			this.manage(request,response);
		}
		
		else if("updatrolemenu".equals(flag)){
			this.updatrolemenu(request,response);
		}
		
		else if("listadmin".equals(flag)){
			this.listAdmin(request,response);
		}
		
		else if("delete".equals(flag)){
			this.delete(request,response);
		}
		
		else if("updateadminrole".equals(flag)){
			this.updateAdminRole(request,response);
		}
	}

	//ɾ����ɫ
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int roleId=Integer.parseInt(request.getParameter("roleId"));
		
		//��ѯ������û���û����������ɫ,�����,����ɾ��
		int adminCount = roleDao.getAdminCountByRoleId(roleId);
		if(adminCount>0){
			request.setAttribute("msg", "���� "+adminCount +" ������Ա��ʹ�������ɫ,��ɫ��Ϣɾ��ʧ�� !");
		}
		else{
			request.setAttribute("msg", "��ɫ��Ϣɾ���ɹ�!");
			roleDao.deleteRole(roleId);
		}

		this.manage(request, response);
	}

	//�����û���ɫ
	private void updateAdminRole(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int roleId=Integer.parseInt(request.getParameter("roleId"));
		int adminId=Integer.parseInt(request.getParameter("adminId"));
		
		if(roleDao.updateAdminRole(roleId,adminId)==1){
			request.setAttribute("msg", "�û���ɫ��Ϣ���³ɹ�!");
			request.getRequestDispatcher("perm/adminrole_edit.jsp").forward(request, response);
		}
		
	}

	//��ѯ�������Ñ�����Ϣ,ת���û���ɫ����ҳ
	private void listAdmin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int pageIndex=1;
		
		String pageIndexStr=request.getParameter("pageIndex");
		if(!StrUtil.isNullOrEmpty(pageIndexStr)){
			pageIndex=Integer.parseInt(pageIndexStr);
		}
		
		int rowCount=adminDao.getAdminCount();
		
		PageInfo page= PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
		List<AdminInfo> adminList=adminDao.getAdminList(page);
		
		request.setAttribute("adminList", adminList);
		request.setAttribute("pageInfo", page);

		request.getRequestDispatcher("/perm/listadmin.jsp").forward(request, response);

	}

	//���½�ɫ����Ӧ��Ȩ�޲˵�
	private void updatrolemenu(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, NumberFormatException {
		int roleId=Integer.parseInt(request.getParameter("roleId"));
		String [] idList=request.getParameterValues("menuIds");
		
		roleDao.updateRoleMenu(roleId,idList);
		
		request.setAttribute("msg", "�����ɹ�");
		request.getRequestDispatcher("/perm/rolemenu_edit.jsp").forward(request, response);;	
	}

	//��ѯ��ɫ�б�,�䵽��ɫ����Ա��
	private void manage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<RoleInfo> roleList=roleDao.getRoleList();
		request.setAttribute("roleList", roleList);
		request.getRequestDispatcher("/perm/role_manage.jsp").forward(request, response);
	}

	//��ӽ�ɫ
	private void addRole(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String roleName=request.getParameter("roleName");
		String des=request.getParameter("des");
		
		RoleInfo role=new RoleInfo();
		role.setRoleName(roleName);
		role.setDes(des);
		
		if(roleDao.addRole(role)==1){
			request.setAttribute("msg", "��ɫ��ӳɹ�!");
			request.getRequestDispatcher("/perm/role_add.jsp").forward(request,response);
		}
	}

}
