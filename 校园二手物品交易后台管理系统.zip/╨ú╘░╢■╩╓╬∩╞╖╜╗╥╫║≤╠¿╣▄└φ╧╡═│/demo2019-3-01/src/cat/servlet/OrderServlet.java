package cat.servlet;

import cat.beans.OrderGoods;
import cat.beans.OrderInfo;
import cat.commons.Enums;
import cat.dao.OrderDao;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import cat.utils.StrUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrderDao orderDao=new OrderDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String flag=request.getParameter("flag");
		if("manage".equals(flag)){
			this.manage(request,response);	
		}
		
		else if("orderview".equals(flag)){
			this.orderView(request,response);
		}
		
		else if("sendgoods".equals(flag)){
			this.sendgoods(request,response);
		}
		
		else if("del".equals(flag)){
			this.del(request,response);
		}

	}

	//ɾ������
	private void del(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int orderId=Integer.parseInt(request.getParameter("id"));
		orderDao.deleteOrder(orderId);
		request.setAttribute("msg", "����ɾ���ɹ�! ");
		this.manage(request, response);
	}

	//��������
	private void sendgoods(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int orderId=Integer.parseInt(request.getParameter("id"));
		if(orderDao.sendGoods(orderId, Enums.EnumOrderState.�ѷ���.toString())==1){
			request.setAttribute("msg","���������ɹ�!");
			this.manage(request,response);	
		}	
	}

	//��ѯ��������Ϣ,�䵽�����鿴ҳ��
	private void orderView(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		int orderId=Integer.parseInt(request.getParameter("id"));
		OrderInfo order=orderDao.getOrderById(orderId);
		List<OrderGoods>goodsList=orderDao.getGoodslist(orderId);
		
		request.setAttribute("order",order);
		request.setAttribute("goodsList", goodsList);
		
		request.getRequestDispatcher("/order/order_details.jsp").forward(request, response);
	
	}

	//��ҳ��ѯ�����б� 
	private void manage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String orderNo= StrUtil.isNullOrEmpty(request.getParameter("orderNo"))?"":request.getParameter("orderNo");
		String beginDate= StrUtil.isNullOrEmpty(request.getParameter("beginDate"))?"":request.getParameter("beginDate");
		String endDate= StrUtil.isNullOrEmpty(request.getParameter("endDate"))?"":request.getParameter("endDate");
		String orderState= StrUtil.isNullOrEmpty(request.getParameter("orderState"))?"":request.getParameter("orderState");

		int pageIndex= StrUtil.isNullOrEmpty(request.getParameter("pageIndex"))?1:Integer.parseInt(request.getParameter("pageIndex"));
		
		int rowCount=orderDao.getOrderCount(orderNo,orderState,beginDate,endDate);
		PageInfo page= PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
		List<OrderInfo> orderList=orderDao.getOrderList(orderNo,orderState,beginDate,endDate,page);
		
		request.setAttribute("orderList", orderList);
		request.setAttribute("pageInfo", page);
		request.getRequestDispatcher("/order/order_manage.jsp").forward(request, response);	
	}

}
