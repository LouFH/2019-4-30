package cat.servlet;

import cat.beans.MemberInfo;
import cat.commons.Enums;
import cat.dao.MemberDao;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import cat.utils.StrUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberDao memberDao=new MemberDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String flag=request.getParameter("flag");
		if("manage".equals(flag)){
			this.manage(request,response);
		}
		else if("del".equals(flag)){
			this.del(request,response);
		}
	
	}

	//ɾ����Ա��Ϣ
	private void del(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		if(memberDao.delMemberById(id)==1){
			request.setAttribute("msg", "�û���Ϣɾ���ɹ�! ");
			this.manage(request, response);
		}	
	}

	//��ҳ��������ѯ��Ա�б�
	private void manage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String  memberNo=StrUtil.isNullOrEmpty(request.getParameter("memberNo"))?"":request.getParameter("memberNo");
		String beginDate=StrUtil.isNullOrEmpty(request.getParameter("beginDate"))?"":request.getParameter("beginDate");
		String endDate=StrUtil.isNullOrEmpty(request.getParameter("endDate"))?"":request.getParameter("endDate");
		int pageIndex=StrUtil.isNullOrEmpty(request.getParameter("pageIndex"))?1:Integer.parseInt(request.getParameter("pageIndex"));
		
		int rowCount=memberDao.getMemberCount(memberNo,beginDate,endDate);

		PageInfo pageInfo=PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
		List<MemberInfo> memberList=memberDao.getMemberList(memberNo,beginDate,endDate,pageInfo);
		request.setAttribute("memberList", memberList);
		request.setAttribute("pageInfo", pageInfo);
		request.getRequestDispatcher("/member/member_manage.jsp").forward(request, response);
	}

}
