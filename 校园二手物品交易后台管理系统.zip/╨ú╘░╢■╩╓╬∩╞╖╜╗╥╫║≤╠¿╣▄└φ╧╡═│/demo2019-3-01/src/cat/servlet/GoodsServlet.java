package cat.servlet;

import cat.beans.GoodsInfo;
import cat.commons.Enums;
import cat.dao.GoodsDao;
import cat.utils.PageInfo;
import cat.utils.PageUtil;
import com.jspsmart.upload.SmartFile;
import com.jspsmart.upload.SmartRequest;
import com.jspsmart.upload.SmartUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspFactory;
import javax.servlet.jsp.PageContext;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class GoodsServlet extends HttpServlet  {
	private static final long serialVersionUID = 1L;
	
	private GoodsDao goodsDao=new GoodsDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String flag=request.getParameter("flag");
		if("add".equals(flag)){
			this.add(request,response);
		}
		
		else if("manage".equals(flag)){
			this.manage(request,response);
		}
		
		else if("update".equals(flag)){
			this.update(request,response);
		}
		
		else if("del".equals(flag)){
			this.del(request,response);
		}	
	}
	
	//ɾ����Ʒ
	private void del(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int goodsId= Integer.parseInt(request.getParameter("goodsId"));
		if(goodsDao.delGoodsById(goodsId)==1){
			request.setAttribute("msg", "��Ʒ��Ϣɾ���ɹ�!");
			this.manage(request, response);
		}	
	}

	//�޸���Ʒ��Ϣ
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SmartUpload smart = new SmartUpload();
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);
	
		try {
			smart.initialize(pageContext);
			smart.upload();	
			SmartFile f=smart.getFiles().getFile(0);  //ȡ���ϴ��������ļ�
			
			// ��Ʒ��Ϣ
		    SmartRequest req=smart.getRequest();
		    int goodsId=Integer.parseInt(req.getParameter("goodsId")); // ����Ҫ�޸ĵ���Ʒ,��Ӧ����ID��
		  	String goodsName = req.getParameter("goodsName");
		  	int bigCateId=Integer.parseInt(req.getParameter("bigCateId"));
		  	int smallCateId=Integer.parseInt(req.getParameter("smallCateId"));
		  	String unit=req.getParameter("unit");
			float price = Float.parseFloat( req.getParameter("price"));
			String producter=req.getParameter("producter");		
			String des = req.getParameter("des");
			
			GoodsInfo goods=goodsDao.getGoodsById(goodsId);
			
			String oldPicture=goods.getPicture();  //ԭ����ͼƬ����
		    
		    goods.setGoodsName(goodsName);
		    goods.setBigCateId(bigCateId);
		    goods.setSmallCateId(smallCateId);
		    goods.setUnit(unit);
		    goods.setPrice(price);
		    goods.setProducter(producter);
		    goods.setDes(des);
		     
			if( f.getSize()!=0){ 
				/* ����û�û���ϴ�ͼƬ,	��ʾ�û��������ԭ����ͼƬ,�����ʾ�û�Ҫ��ͼƬ */
				goods.setPicture(f.getSize()==0?oldPicture:UUID.randomUUID().toString());
			}

		    if(goodsDao.updateGoods(goods)==1)
		    {	
		    	if(f.getSize()!=0){
		    		//��ɾ��ԭ����ͼƬ
		    		File oldPic=new File(getServletContext().getRealPath("/")+"images/upload_goodsimgs/"+oldPicture);
		    		oldPic.delete();
		    		
		    		//�ٰ���ͼƬ����
		    		f.saveAs("/images/upload_goodsimgs/"+goods.getPicture()); 
		    	}
			    request.setAttribute("msg", "��Ʒ��Ϣ�޸ĳɹ�!");
			    request.setAttribute("goods", goods);  //��Ϊǰ��Ҫ�������ݻ���,�������ϴ���,����ǰ���޷�ʹ�� ${param.������}�ķ�ʽ
			    request.getRequestDispatcher("/goods/goods_edit.jsp").forward(request,response);
		    }
		}
		catch(Exception ex){
			ex.printStackTrace();
		    request.setAttribute("msg", "����ʧ��!");
		    request.getRequestDispatcher("/goods/goods_edit.jsp").forward(request,response);	
		}	
	}

	//��Ʒά��(��ѯ��Ʒ�б�)
	private void manage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int bigCateId=request.getParameter("bigCateId")==null?0:Integer.parseInt(request.getParameter("bigCateId"));
		int smallCateId=request.getParameter("smallCateId")==null?0:Integer.parseInt(request.getParameter("smallCateId"));
		int pageIndex=request.getParameter("pageIndex")==null?1:Integer.parseInt(request.getParameter("pageIndex"));
		String goodsName=request.getParameter("goodsName"); 
		
		int rowCount=goodsDao.getGoodsCount(bigCateId,smallCateId,goodsName);
		
		PageInfo pageInfo=PageUtil.getPageInfo(Enums.PAGESIZE, rowCount, pageIndex);
		List<GoodsInfo> goodsList= goodsDao.getGoodsList(bigCateId,smallCateId,goodsName,pageInfo);
		request.setAttribute("goodsList", goodsList);
		request.setAttribute("pageInfo", pageInfo);
		request.getRequestDispatcher("/goods/goods_manage.jsp").forward(request, response);
		
	}

	//�����Ʒ(��ͼƬ�ϴ�)
	private void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SmartUpload smart = new SmartUpload();
		PageContext pageContext = JspFactory.getDefaultFactory().getPageContext(this, request, response, null, true, 8192, true);

		try {
			smart.initialize(pageContext);
			smart.upload();	
			SmartFile f=smart.getFiles().getFile(0);  //ȡ���ϴ��������ļ�
			
			// ����Ʒ��Ϣ�����ݿ���    
		    SmartRequest req=smart.getRequest();
		  	String goodsName = req.getParameter("goodsName");
		  	int bigCateId=Integer.parseInt(req.getParameter("bigCateId"));
		  	int smallCateId=Integer.parseInt(req.getParameter("smallCateId"));
		  	String unit=req.getParameter("unit");
			float price = Float.parseFloat( req.getParameter("price"));
			String producter=req.getParameter("producter");		
			String picture=f.getSize()==0?"":UUID.randomUUID().toString(); //��ƷͼƬ����,ʹ��UUID
		    String des = req.getParameter("des");
 
		    GoodsInfo goods=new GoodsInfo();
		    
		    goods.setGoodsName(goodsName);
		    goods.setBigCateId(bigCateId);
		    goods.setSmallCateId(smallCateId);
		    goods.setUnit(unit);
		    goods.setPrice(price);
		    goods.setProducter(producter);
		    goods.setPicture(picture);
		    goods.setDes(des);
		    goods.setPicture(picture);
		    goods.setPrice(price);
		  
		    if(goodsDao.addGoods(goods)==1)
		    {	
		    	if(f.getSize()!=0){
		    		f.saveAs("/images/upload_goodsimgs/"+goods.getPicture()); 
		    	}
			    request.setAttribute("msg", "��Ʒ��ӳɹ�");
			    request.setAttribute("goods", goods);  //��Ϊǰ��Ҫ�������ݻ���,�������ϴ���,����ǰ���޷�ʹ�� ${param.������}�ķ�ʽ
			    request.getRequestDispatcher("/goods/goods_add.jsp").forward(request,response);
		    }
		}
		catch(Exception ex){
			ex.printStackTrace();
		    request.setAttribute("msg", "����ʧ��!");
		    request.getRequestDispatcher("/goods/goods_add.jsp").forward(request,response);	
		}
		    
		
	}

}
