package cat.commons;

//��ҳ������
public class PageUtil {
	public static PageInfo getPageInfo(int pageSize, int rowCount, int pageIndex){
		PageInfo page=new PageInfo();
		
		page.setPageSize(pageSize==0?10:pageSize);
		page.setPageIndex(pageIndex);
		page.setRowCount(rowCount);
		page.setBeginRow(pageSize*(pageIndex-1));
		page.setPageCount((rowCount+pageSize-1)/pageSize);
		
		page.setHasNext( !( pageIndex==page.getPageCount()));
		page.setHasPre( !(pageIndex==1|| rowCount==0));
		
		return page;
	}
}
