package cat.beans;

//��ɫ��Ϣ
public class RoleInfo {
	private int id;  //��ɫid
	private String roleName;  //��ɫ����
	private String des;   //��ɫ����
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
}
