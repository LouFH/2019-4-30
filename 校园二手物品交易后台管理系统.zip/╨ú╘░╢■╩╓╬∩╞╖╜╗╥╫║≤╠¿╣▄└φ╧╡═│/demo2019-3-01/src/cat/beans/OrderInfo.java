package cat.beans;

import cat.commons.Enums;

import java.sql.Timestamp;

//������Ϣ
public class OrderInfo {
	private int id; 
	private String orderNo;     //�������
	private Enums.EnumPayMethod payMethod; //���ʽ
	private int memberId;   //��Աid (������ο�ֱ�ӹ���,��û�д�id)
	private float postage;  //�ʷ�
	private Enums.EnumPostMethod postMethod;  //�ʵݷ�ʽ
	private String orderDate;  //������������;
	private String  address;  //�ʼĵ�ַ;
	private Enums.EnumOrderState orderState;  //����״̬
	private String sendDate;  //��������
	private Timestamp editDate;  //�޸�����	
	private float amount; //������
	
	private String memberNo ; //��Ա�˺� ���ݿ���û�д��ֶ�,������ѯ�õ�
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public Enums.EnumPayMethod getPayMethod() {
		return payMethod;
	}
	public void setPayMethod(Enums.EnumPayMethod payMethod) {
		this.payMethod = payMethod;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public float getPostage() {
		return postage;
	}
	public void setPostage(float postage) {
		this.postage = postage;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Enums.EnumOrderState getOrderState() {
		return orderState;
	}
	public void setOrderState(Enums.EnumOrderState orderState) {
		this.orderState = orderState;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	public Timestamp getEditDate() {
		return editDate;
	}
	public void setEditDate(Timestamp editDate) {
		this.editDate = editDate;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public Enums.EnumPostMethod getPostMethod() {
		return postMethod;
	}
	public void setPostMethod(Enums.EnumPostMethod postMethod) {
		this.postMethod = postMethod;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
}
