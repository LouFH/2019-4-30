package cat.beans;

import cat.utils.StrUtil;

import java.io.Serializable;
import java.sql.Timestamp;

//��̨����Ա��Ϣʵ����
public class AdminInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String note;
//	private String noteShow;
	private String adminName;
	private String password;
	private String state; //��ʾ����Ա�Ƿ�ɾ����
	private Timestamp editDate ; //��������,��������,Ҫ��ʱ���
	private int roleId;   //�û���ɫ
	private String roleName;  //�ǻ���ɫ���� (���ݿ���û�и��ֶ�,���ڹ�����ѯ)
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public Timestamp getEditDate() {
		return editDate;
	}
	public void setEditDate(Timestamp editDate) {
		this.editDate = editDate;
	}
	
	public String toString() {
		return "AdminInfo [id=" + id + ", note=" + note + ", adminName="
				+ adminName + ", password=" + password + ", state=" + state
				+ ", editDate=" + editDate + "]";
	}
	
	public String getNoteShow() {
		String str=note;
		if(!StrUtil.isNullOrEmpty(note)){
			if(note.length()>10){
				str=note.substring(0,10)+"...";
			}
		}
		return str;
	}
	
	public void setNoteShow(String noteShow) {
		//this.noteShow = noteShow;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}
