package cat.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

//������֤Session 
public class SessionFilter implements Filter {
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest)request;
		String requestURI=req.getRequestURI();
		String contextPath=req.getContextPath();
		
		//�û�����  /shop-admin  ��   /shop-admin/login.jsp �����ù���
		if((!requestURI.equals(contextPath+"/"))  && (!requestURI.contains("login.jsp"))){
			HttpSession session=req.getSession();
			if(session.getAttribute("admin")==null){  //֤���û�û��¼
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script>window.top.location.href='"+contextPath+"/login.jsp?loginflag=0'</script>");
			}
			else{
				chain.doFilter(request, response);
			}
		}
		else{
			chain.doFilter(request, response);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

	

}
