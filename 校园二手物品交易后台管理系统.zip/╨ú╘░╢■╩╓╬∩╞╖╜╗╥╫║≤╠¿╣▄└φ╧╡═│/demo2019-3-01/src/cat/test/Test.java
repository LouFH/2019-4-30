package cat.test;

import cat.utils.Des;

public class Test {

	public static void main(String[] args) {

	System.out.println(Des.encStr("a"));
		

	}



}

