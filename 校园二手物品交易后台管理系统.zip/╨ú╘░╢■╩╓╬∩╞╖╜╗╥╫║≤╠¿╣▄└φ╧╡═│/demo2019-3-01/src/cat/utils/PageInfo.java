package cat.utils;

public class PageInfo {
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getBeginRow() {
		return beginRow;
	}
	public void setBeginRow(int beginRow) {
		this.beginRow = beginRow;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public boolean isHasPre() {
		return hasPre;
	}
	public void setHasPre(boolean hasPre) {
		this.hasPre = hasPre;
	}
	public boolean isHasNext() {
		return hasNext;
	}
	public void setHasNext(boolean hasNext) {
		this.hasNext = hasNext;
	}
	private int pageSize ;  //ҳ���С
	private int pageCount;   //һ���ж���ҳ
	private int beginRow ;   //�ӵڼ�ҳ��ʼ��
	private int rowCount ;   //һ���ж���
	private int pageIndex;   //��ǰ�ǵڼ�ҳ
	public int getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	private boolean hasPre;   //�Ƿ���ǰһҳ
	private boolean hasNext;  //�Ƿ�����һҳ

}
