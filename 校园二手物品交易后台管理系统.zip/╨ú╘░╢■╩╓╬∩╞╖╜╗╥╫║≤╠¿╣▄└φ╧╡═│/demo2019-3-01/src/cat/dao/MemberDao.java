package cat.dao;

import cat.beans.MemberInfo;
import cat.jdbc.DBUtil;
import cat.utils.PageInfo;
import cat.utils.StrUtil;

import java.util.List;

public class MemberDao {
	
	//���ݻ�Աidɾ����Ա
	public int delMemberById(int id){
		String sql="delete from memberInfo where id=?";
		return DBUtil.update(sql, id);
		
	}
	//���ݻ�Աid��ѯ��Ա��Ϣ
	public MemberInfo getMemeberById(int id){
		String sql="select * from memberInfo where id=? "; 
		return DBUtil.getSingleObj(sql, MemberInfo.class, id);
	}
	/**
	 * @param memberNo ��Ա�˺�
	 * @param beginDate ��Աע����ʼ����
	 * @param endDate ��Աע���������
	 * @param pageInfo ��ҳ��Ϣ
	 * @return ��Ա�б�
	 */
	public List<MemberInfo> getMemberList(String memberNo, String beginDate, String endDate, PageInfo pageInfo) {
		String sql="select * from memberInfo where 1=1 "; 
		
		if(!StrUtil.isNullOrEmpty(memberNo)){
			sql+=" and memberNo='"+memberNo+"' ";
		}
		if(!StrUtil.isNullOrEmpty(beginDate)){
			sql+=" and registerDate>='"+beginDate+"' ";
		}
		if(!StrUtil.isNullOrEmpty(endDate)){
			sql+=" and registerDate <='"+endDate+" 23:59:59' ";
		}
		
		sql+=" order by registerDate desc limit ? , ? "; 
		
		return DBUtil.getList(sql, MemberInfo.class,pageInfo.getBeginRow(),pageInfo.getPageSize());
	}

	//��������ѯ��Ա����
	public int getMemberCount(String memberNo, String beginDate, String endDate) {
		String sql="select count(*) from memberInfo where 1=1 "; 
		
		if(!StrUtil.isNullOrEmpty(memberNo)){
			sql+=" and memberNo='"+memberNo+"' ";
		}
		if(!StrUtil.isNullOrEmpty(beginDate)){
			sql+=" and registerDate>='"+beginDate+"' ";
		}
		if(!StrUtil.isNullOrEmpty(endDate)){
			sql+=" and registerDate <='"+endDate+" 23:59:59' ";  
		}

		Long  count= DBUtil.getScalar(sql);
		
		return new Integer(count+""); 
	}
}
