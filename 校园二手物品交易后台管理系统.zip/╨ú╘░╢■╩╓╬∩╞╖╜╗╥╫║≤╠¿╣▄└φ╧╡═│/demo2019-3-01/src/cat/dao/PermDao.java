package cat.dao;

import cat.jdbc.DBUtil;
import cat.utils.StrUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//����Ȩ�޹���
public class PermDao {
	
	public static void main(String[] args) {
		System.out.println(new PermDao().getPermIdList(56));
	}
	
	public String getPermIdList(int adminId){
		String resultStr="";
		Connection  conn=null;
		ResultSet rs=null;
	    PreparedStatement stm=null;
	    try{
	    	conn=DBUtil.getConn();
	    	String sql="select menuId from adminmenu where adminId=?";
	    	stm=conn.prepareStatement(sql);
	    	stm.setInt(1, adminId);
	    	
	    	rs=stm.executeQuery();
	    	while(rs.next()){
	    		resultStr+=rs.getInt(1)+",";
	    	}
	    }catch(Exception ex){
	    	ex.printStackTrace();
	    }finally{
	    	DBUtil.close(rs,stm,conn);
	    }
	
		if(!StrUtil.isNullOrEmpty(resultStr)){
			resultStr= resultStr.substring(0,resultStr.length()-1);   //Ҫ�ǵ�ȥ�����һ������
		}
		
		return resultStr;
		
		
	}
	/**
	 * �����û�Ȩ��,������������
	 * @param adminId �û���id
	 * @param idList �µ�Ȩ��id�б�
	 */
	public void updatePerm(int adminId, String[] idList) {
		Connection conn=null;
		PreparedStatement stm=null;
		
		try {
			conn=DBUtil.getConn();
			String sql="delete from adminmenu where adminId= "+ adminId;
			stm=conn.prepareStatement(sql);
			
			conn.setAutoCommit(false);  //��������
			stm.execute();  //ɾ���û�ԭ�е�Ȩ��
			
			for(String id:idList){
				String sq2="insert into adminmenu(adminid,menuId) values(?,?)"; 
				stm=conn.prepareStatement(sq2);
				stm.setInt(1,adminId);
				stm.setInt(2,Integer.parseInt(id));
				
				stm.execute(); 
			}
			
			conn.commit();  //�ύ����	
		} 
		
		catch (Exception e) {
			try {
				conn.rollback();  //�ع�����
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			DBUtil.close(null,stm,conn);
		}
		
		
	}

}
