package cat.dao;

import cat.beans.GoodsInfo;
import cat.jdbc.DBUtil;
import cat.utils.PageInfo;
import cat.utils.StrUtil;

import java.util.List;

//��Ʒ�������
public class GoodsDao {
	
	//ɾ����Ʒ��Ϣ
	public int delGoodsById(int id){
		String sql="delete from goodsInfo where id=?";
		return DBUtil.update(sql, id);
	}
	//������Ʒid��ѯ��Ʒ��Ϣ
	public GoodsInfo getGoodsById(int goodsId){
		String sql="select * from goodsInfo where id=?" ;
		return DBUtil.getSingleObj(sql, GoodsInfo.class, goodsId);
	}
	
	//������Ʒ��Ϣ
	public int updateGoods(GoodsInfo goods){
		String sql="update goodsInfo  set goodsName=? ,unit=? ,picture=?,price=?,des=?,producter=?,bigCateId=?, smallCateId=?  where id=?";
		Object [] params={
				goods.getGoodsName(),
				goods.getUnit(),
				goods.getPicture(),
				goods.getPrice(),
				goods.getDes(),
				goods.getProducter(),
				goods.getBigCateId(),
				goods.getSmallCateId(),
				goods.getId()
		};
		
		return DBUtil.update(sql, params);
	}
	 
	//��������ҳ��ѯ��Ʒ�б�
	public List<GoodsInfo> getGoodsList(int bigCateId, int smallCateId, String goodsName, PageInfo pageInfo) {
	//	String sql= "select a.* , from goodsInfo where 1=1 " ;	
		String sql= " select temp.*,b.cateName as smallCateName from "
				+ "(select a.*,b.cateName as bigCateName from goodsInfo a left join cateInfo b on a.bigcateId=b.id) temp "
				+ " left join cateInfo b on temp.smallcateId=b.id  where 1=1 " ; 
		  
		if(bigCateId!=0){
			sql+=" and bigCateId="+bigCateId;
		}
	
		if(bigCateId!=0){
			sql+=" and smallCateId="+smallCateId;
		}
		
		if(!StrUtil.isNullOrEmpty(goodsName)){
			sql+=" and goodsName like '%"+goodsName+"%'";
		}
		
		sql+=" order by editDate desc limit ?,?";
		
		return DBUtil.getList(sql, GoodsInfo.class, pageInfo.getBeginRow(),pageInfo.getPageSize());	
	}
	
	//��ѯ��Ʒ����(���ڷ�ҳ)
	public int getGoodsCount(int bigCateId,int smallCateId,String goodsName){
		String sql= "select count(*) from goodsInfo where 1=1 " ;
		
		if(bigCateId!=0){
			sql+=" and bigCateId="+bigCateId;
		}
	
		if(bigCateId!=0){
			sql+=" and smallCateId="+smallCateId;
		}
		
		if(!StrUtil.isNullOrEmpty(goodsName)){
			sql+=" and goodsName like '%"+goodsName+"%'";
		}
		
		return new Integer(DBUtil.getScalar(sql)+"");
	}
	//�����Ʒ
	public int addGoods(GoodsInfo goods) {
		String sql="insert into goodsInfo (goodsName,bigCateId,smallCateId,unit,picture,price,producter,des)  values (?,?,?,?,?,?,?,?)";
		Object [] params={
				goods.getGoodsName(),
				goods.getBigCateId(),
				goods.getSmallCateId(),
				goods.getUnit(),
				goods.getPicture(),
				goods.getPrice(),
				goods.getProducter(),
				goods.getDes(),	
		};
		
		return DBUtil.update(sql, params);
	}
	

}

